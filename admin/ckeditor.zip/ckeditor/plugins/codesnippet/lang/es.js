﻿/*
 Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang("codesnippet","es",{button:"Insertar fragmento de código",codeContents:"Contenido del código",emptySnippetError:"Un fragmento de código no puede estar vacío.",language:"Lenguaje",title:"Fragmento de código",pathName:"fragmento de código"});